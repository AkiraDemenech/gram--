Baixe os arquivos desta pasta no seu computador e deixe-os todos juntos num mesmo local.
	lab.txt é a a tabela com as informações das bactérias (linhas) e os testes (colunas, separadas por tab),
	lab.log é gerado pelo programa com a lista de objetos extraídos da tabela,
	lab.py é o programa.
	lab.pyw abre o programa sem a janela do console.
	bac.py é um script onde estão definidos os cálculos de probabilidades para ranquear as bactérias 

** Todos os arquivos devem estar na mesma pasta, incluindo o script bac.py 

Arquivos adicionais gerados:
	lab.java é a lista de objetos extraídos da tabela no formato utilizado pela versão Java
	lab.js é a lista de objetos extraídos da tabela em formato JSON 

É necessário ter as bibliotecas Tkinter e Numpy instaladas para rodar o programa.
 * Execute com o interpretador Python
	Caso você não tenha Python instalado no seu computador, baixe e instale em https://www.python.org/downloads/ 

Depois de instalar, abra a pasta onde estão os arquivos do programa baixados.
Abra nela um terminal ou prompt de comando e instale as bibliotecas com o seguinte comando:
	pip install -r requirements.txt
Caso esse comando não seja reconhecido pelo sistema, tente as seguintes variações: 
	python -m pip install -r requirements.txt
	python3 -m pip install -r requirements.txt
	py -m pip install -r requirements.txt	

Para rodar o programa, dê duplo clique no arquivo lab.pyw  
Se isso abrir o texto do arquivo, abra um terminal ou prompt de comando na pasta onde estão baixados os arquivos do programa e tente os seguintes comandos:
	python lab.pyw
	python3 lab.pyw
	py lab.pyw
